'''creates symlinks for packages that are not virtual environment aware'''
import os
import os.path
#set up logging
import logging

date_fmt = "%Y-%m-%d,%H:%M:%S"
log_format = "%(levelname)s %(asctime)s.%(msecs)03d %(threadName)s %(name)s.%(funcName)s %(message)s"
logging.basicConfig(format=log_format, datefmt=date_fmt, level=logging.INFO)

_logger = logging.getLogger(__name__)
_logger.debug('executing name %s in file %s', __name__, __file__)

def main():
    '''creates symlinks for packages that are not virtual environment aware'''
    _logger.debug('entered main')

    venv_folder = '/home/pi/pi2fa/venv/lib/python3.9/site-packages'
    _logger.debug("checking to see if venv_folder '%s' exists", venv_folder)
    assert os.path.exists(venv_folder)

    sources = [
        '/usr/lib/python3/dist-packages/gi'
    ]

    for src in sources:
        _logger.debug("checking to see if '%s' exists", src)
        assert os.path.exists(src)
        #check to see if the link already exists
        dest = os.path.join(venv_folder, os.path.basename(src))
        if os.path.exists(dest):
            _logger.debug("skipping symlink creation, dest '%s' already exists", dest)
        else:
            _logger.debug("creating symlink from '%s' to '%s'", src, dest)
            os.symlink(src, dest)

if __name__ == main():
    main()
