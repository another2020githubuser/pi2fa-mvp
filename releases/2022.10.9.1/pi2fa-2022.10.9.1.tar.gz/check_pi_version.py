'''Verifies Running a Raspberry Pi 3B/3B+'''
import logging
import sys
import io
date_fmt = "%Y-%m-%d,%H:%M:%S"
log_format = "%(levelname)s %(asctime)s.%(msecs)03d %(threadName)s %(name)s.%(funcName)s %(message)s"
logging.basicConfig(format=log_format, datefmt=date_fmt, level=logging.INFO)

_logger = logging.getLogger(__name__)
_logger.debug('executing name %s in file %s', __name__, __file__)

def main():
    try:
        with io.open('/sys/firmware/devicetree/base/model', 'r') as m:
            #remove unprintable character from end of read string
            pi_model_read = m.read()[:-1]
            _logger.debug("Pi model = %s and has length %d", pi_model_read, len(pi_model_read))
            pi_model_desired = 'Raspberry Pi 3 Model B'
            _logger.debug("pi_model_desired = %s, and has length %d", pi_model_desired, len(pi_model_desired))
            if pi_model_desired in pi_model_read:
                _logger.info("Raspberry Pi 3B/3B+ Detected, continuing")
                sys.exit(0)
            else:
                _logger.debug("Not a Raspberry 3B/3B+, aborting")
                sys.exit(1)
    except Exception as exception:
        _logger.warning("Exception while trying to read model, aborting")
        _logger.error(exception)
        sys.exit(1)

if __name__ == "__main__":
    main()
