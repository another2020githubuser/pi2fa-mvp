'''Verifies Pi Running OS Version bullseye'''
import logging
import sys
import io
date_fmt = "%Y-%m-%d,%H:%M:%S"
log_format = "%(levelname)s %(asctime)s.%(msecs)03d %(threadName)s %(name)s.%(funcName)s %(message)s"
logging.basicConfig(format=log_format, datefmt=date_fmt, level=logging.INFO)

_logger = logging.getLogger(__name__)
_logger.debug('executing name %s in file %s', __name__, __file__)

def main():
    try:
        with io.open('/etc/os-release', 'r') as fp:
            lines = fp.read().split('\n')
            _logger.debug("%d lines", len(lines))
            for line in lines:
                _logger.debug("line = %s", line)
                key, value = line.split('=')
                if key == "VERSION_CODENAME":
                    _logger.debug("Found key VERSION_CODENAME")
                    if value == "bullseye":
                        _logger.debug("running bullseye, continuing")
                        sys.exit(0)
                    else:
                        _logger.debug("NOT running bullseye, aborting.  Detected OS = '%s'", value)
                        sys.exit(1)
    except Exception as ex:
        _logger.warning("Exception while trying to find os, aborting")
        _logger.error(ex)
        sys.exit(1)

if __name__ == "__main__":
    main()
